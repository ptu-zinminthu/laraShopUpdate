<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{

	use SoftDeletes; //SoftDeletes is trait (trait  is some part of class) .

	public $table = 'categories';

    protected $fillable = [
    'title', 'icon_image', 'parent_id'
    ];

    protected $hidden = [
   //
    ];
}
