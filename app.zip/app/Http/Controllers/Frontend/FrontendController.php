<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Product;

/**
 * Class FrontendController
 * @package App\Http\Controllers
 */
class FrontendController extends Controller
{
	/**
	 * @return \Illuminate\View\View
	 */
	public function index()
	{
		$categories = Category::where("parent_id",0)->get();
		$products = Product::where("category_id",13)->get();
		$vegitable_products = Product::where("category_id",33)->get();
		$beverage_products =  Product::where("category_id",32)->get();
		return view('frontend.index')->with(array("categories"=>$categories,"products"=>$products,"vegitable_products"=>$vegitable_products,"beverage_products" =>$beverage_products));
	}

	public function products(){

		$categories = Category::where("parent_id",0)->get();
		$food_products = Product::where("category_id",31)->get();
		$vegitable_products= Product::where("category_id",33)->get();
		$beverage_products= Product::where("category_id",32)->get();
		$fashion_products = Product::where("category_id",15)->get();
		$it_products = Product::where("category_id",15)->get();
		$costmetic_products = Product::where("category_id",15)->get();
		return view('frontend.products.index')
		->with(array(
			"categories"=>$categories,
			"vegitable_products"=>$vegitable_products,
			"beverage_products"=>$beverage_products,
			"food_products"=>$food_products,
			"fashion_products"=>$fashion_products,
			"it_products"=>$it_products,
			"costmetic_products"=>$costmetic_products));
	}

	/**
	 * @return \Illuminate\View\View
	 */
	public function macros()
	{
		$categories = Category::where("parent_id",0)->get();
		return view('frontend.macros')->with(array(
			"categories"=>$categories));
	}

	public function services()
	{
		$categories = Category::where("parent_id",0)->get();
		return view('frontend.services')->with(array(
			"categories"=>$categories));
	}
	public function event()
	{
		$categories = Category::where("parent_id",0)->get();
		return view('frontend.event')->with(array(
			"categories"=>$categories));
	}
	public function about()
	{
		$categories = Category::where("parent_id",0)->get();
		return view('frontend.about')
		->with(array(
			"categories"=>$categories));
	}
	public function mail()
	{
		$categories = Category::where("parent_id",0)->get();
		return view('frontend.mail')
		->with(array(
			"categories"=>$categories));
	}
	public function vegetable()
	{
		$vegitable_products= Product::where("category_id",33)->get();
		$categories = Category::where("parent_id",0)->get();
		return view('frontend.vegetable')
		->with(array(
			"categories"=>$categories,"vegitable_products" =>$vegitable_products));
	}
		public function beverages()
	{
		$beverage_products= Product::where("category_id",32)->get();
		$categories = Category::where("parent_id",0)->get();
		return view('frontend.beverages')
		->with(array(
			"categories"=>$categories,"beverage_products" =>$beverage_products));
	}

		public function foods()
	{
		$food_products= Product::where("category_id",31)->get();
		$categories = Category::where("parent_id",0)->get();
		return view('frontend.foods')
		->with(array(
			"categories"=>$categories,"food_products" =>$food_products));
	}

	public function detail($id)
	{
		 // $vegitable_products = Product ::find($id);
    
   //      // $food_products = Category::all()->pluck("title","id");
   //       return view('frontend.detail')->with(array(
   //           "vegitable_products" => $vegitable_products,));
    }
	
}
