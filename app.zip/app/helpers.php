<?php

/**
 * Global helpers file with misc functions
 */

if (! function_exists('app_name')) {
	/**
	 * Helper to grab the application name
	 *
	 * @return mixed
	 */
	function app_name()
	{
		return config('app.name');
	}
}

if (! function_exists('access')) {
	/**
	 * Access (lol) the Access:: facade as a simple function
	 */
	function access()
	{
		return app('access');
	}
}

if ( ! function_exists('history'))
{
	/**
	 * Access the history facade anywhere
	 */
	function history()
	{
		return app('history');
	}
}

if (! function_exists('gravatar')) {
	/**
	 * Access the gravatar helper
	 */
	function gravatar()
	{
		return app('gravatar');
	}
}

if (! function_exists('includeRouteFiles')) {

	/**
	 * Loops through a folder and requires all PHP files
	 * Searches sub-directories as well
	 * @param $folder
	 */
	function includeRouteFiles($folder)
	{
		$directory =  $folder;
		$handle = opendir($directory);
		$directory_list = [$directory];

		while (false !== ($filename = readdir($handle))) {
			if($filename != "." && $filename != ".." && is_dir($directory.$filename))
				array_push($directory_list, $directory.$filename."/");
		}

		foreach ($directory_list as $directory) {
			foreach (glob($directory."*.php") as $filename) {
				require($filename);
			}
		}
	}
}